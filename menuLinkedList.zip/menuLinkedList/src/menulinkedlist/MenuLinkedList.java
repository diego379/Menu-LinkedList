
package menulinkedlist;

import java.awt.Font;
import javax.swing.UIManager; 
import java.util.LinkedList;
import javax.swing.JOptionPane;
import javax.swing.plaf.ColorUIResource;
import javax.swing.ImageIcon;


public class MenuLinkedList {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        
        LinkedList<String> lista = new LinkedList<>();
        
        int opcion = 0,otroNombre, eliminarPosicion = 0, opcionEliminar, eliminarPrimero, eliminarUltimo, modificarNum, limpiarLista = 0;
        String agregar,agregarPrimero,agregarUltimo, eliminar = " ",eliminarNombre, modificar = "",nuevoNombre;
  
       
        
        //CAMBIO DE COLOR DEL JOPTIONPANE
        UIManager UI=new UIManager();   
        UI.put("OptionPane.background",new ColorUIResource(41, 223, 255  )); //COLOR DE BORDE
        UI.put("Panel.background",new ColorUIResource(179, 249, 250 )); //COLOR DE FONDO 
        
        
        
        
        // CAMBIO DE FUENTE
        Font fuente = new Font (Font.SANS_SERIF, Font.PLAIN, 20); 
        UIManager.put ("OptionPane.messageFont", fuente);  //FUENTE DE INFORMACION
        UIManager.put ("OptionPane.buttonFont", fuente);  //FUENTE DE BOTONES
        
        
 
         
        
        
            
            
            do{ 
                       
                try {
                    
                     //JOptionPane.showMessageDialog(null, "Digite un nombre valido", "ATENCION", JOptionPane.INFORMATION_MESSAGE, new ImageIcon("src/images/error.png"));
                    
                      opcion = Integer.parseInt((String) JOptionPane.showInputDialog(null,"\n1. Agregar nombre\n"+
                                                  "2. Agregar nombre en la primera posicion\n"+
                                                  "3. Agregar nombre en la ultima posicion\n"+
                                                  "4. Eliminar Nombre\n"+
                                                  "5. Eliminar nombre de la primera posicion\n"+
                                                  "6. Eliminar nombre de la ultima posicion\n"+
                                                  "7. Modificar nombre\n"
                                                  +"8. Mostrar la cantidad de nombres de la lista\n"
                                                  +"9. Borrar toda la lista\n"
                                                  +"10. Salir\n\n"+"-----------------------------------------------------------\n"+"                         LINKEDLIST\n\n"+lista,"                                                                   LINKEDLIST",JOptionPane.INFORMATION_MESSAGE, new ImageIcon("src/images/poli.gif"),null,null));
        
                    
                         switch(opcion){
                             
                             case 1 :
                                 
 
                                 do{
                            
                                 
                                 agregar = (String) JOptionPane.showInputDialog(null,"Por favor ingrese el nombre que desea guardar en la lista","INGRESAR NOMBRE",JOptionPane.INFORMATION_MESSAGE, new ImageIcon("src/images/lista.jpg"),null,null);
                                 
                               
                                 while(agregar.equals("")) {
                                        
                                            JOptionPane.showMessageDialog(null, "El campo no puede estar vacio", "ATENCION",JOptionPane.INFORMATION_MESSAGE, new ImageIcon("src/images/error.jpg"));
                                            agregar = (String) JOptionPane.showInputDialog(null,"Por favor ingrese el nombre que desea guardar en la lista","AGREGAR NOMBRE",JOptionPane.INFORMATION_MESSAGE, new ImageIcon("src/images/lista.jpg"),null,null);
                                                      }
                                                    lista.add(agregar);
                                                            
                                            otroNombre = JOptionPane.showConfirmDialog(null,"¿ Desea guardar otro nombre ?","AGREGAR NOMBRE", JOptionPane.YES_OPTION , JOptionPane.NO_OPTION, new ImageIcon("src/images/agregar.jpg"));        
                                                    
                                 }while(otroNombre == JOptionPane.YES_OPTION );                
                                   
                                 break;
                             
                             case 2 : 
 
                                  agregarPrimero = (String) JOptionPane.showInputDialog(null,"Por favor ingrese el nombre que desea guardar en la Primera posicion\n\n" + lista + "\n","PRIMERA POSICION",JOptionPane.INFORMATION_MESSAGE, new ImageIcon("src/images/primero.jpg"),null,null);

                                 while(agregarPrimero.equals("")) {
                                        
                                          JOptionPane.showMessageDialog(null, "El campo no puede estar vacio", "ATENCION",JOptionPane.INFORMATION_MESSAGE, new ImageIcon("src/images/error.jpg"));
                                            agregarPrimero = (String) JOptionPane.showInputDialog(null,"Por favor ingrese el nombre que desea guardar en la Primera posicion\n\n" + lista + "\n","PRIMERA POSICION",JOptionPane.INFORMATION_MESSAGE, new ImageIcon("src/images/primero.jpg"),null,null);
                                                      }
                                                      lista.addFirst(agregarPrimero);
                                 break;
                                 
                             
                             case 3 :
                                  agregarUltimo = (String) JOptionPane.showInputDialog(null,"Por favor ingrese el nombre que desea guardar en la Ultima posicion\n\n" + lista + "\n","ULTIMA POSICION",JOptionPane.INFORMATION_MESSAGE, new ImageIcon("src/images/ultimo.jpg"),null,null);
      
                                 while(agregarUltimo.equals("")) {
                                        
                                            JOptionPane.showMessageDialog(null, "El campo no puede estar vacio", "ATENCION",JOptionPane.INFORMATION_MESSAGE, new ImageIcon("src/images/error.jpg"));
                                            agregarUltimo = (String) JOptionPane.showInputDialog(null,"Por favor ingrese el nombre que desea guardar en la Ultima posicion\n\n" + lista + "\n","ULTIMA POSICION",JOptionPane.INFORMATION_MESSAGE, new ImageIcon("src/images/ultimo.jpg"),null,null);                                            
                                            
                                            
                                                      }
                                                      lista.addLast(agregarUltimo);
                                 break;
                                 
                                 
                             case 4 : 
                                 
                                 do{
                                     

                                 opcionEliminar = Integer.parseInt((String) JOptionPane.showInputDialog(null,"Seleccione de que modo va a eliminar un nombre\n"
                                                                                    +"\n1. Eliminar por posicion\n"
                                                                                    +"2. Eliminar por nombre\n"
                                                                                    +"3. Volver al menu principal\n","ELIMINAR",JOptionPane.INFORMATION_MESSAGE, new ImageIcon("src/images/borrar.jpg"),null,null)); 
                                 
                                 switch(opcionEliminar){
                                     
                                     
                                     case 1:
 
                                         for(int i = 0; i < lista.size(); i++){
                                             
                                              eliminar += (i+1) + ". "+lista.get(i)+"\n";  }
                                         
                                          eliminarPosicion =  Integer.parseInt(JOptionPane.showInputDialog("Por favor ingrese la posicion del nombre que desea borrar\n" + "═══════════════════════════\n\n" + eliminar+"\n")); 
                                          JOptionPane.showMessageDialog(null, "El nombre '"+ lista.get(eliminarPosicion - 1) + "'  ha sido borrado exitosamente" );
                                          lista.remove(eliminarPosicion - 1);
                                         break;
                                         
                                         
                                     
                                     case 2:
                                            
                                        eliminarNombre = JOptionPane.showInputDialog(null, "Por favor escriba el nombre que desea borrar" + "\n\n" + lista,"BORRAR NOMBRE",3);
                                        lista.remove(eliminarNombre);
                                         break; 
                                         
                                         
  
                                     case 3:
                                         break;  
                                 }
                                 }while( opcionEliminar!=3); 
                                 break;
                                 
                                 
                                 
                             case 5 : 
                                 
                                    eliminarPrimero = JOptionPane.showConfirmDialog(null, "¿ Esta seguro(a) de eliminar el primer nombre de la lista ? \n" + "\nPrimer nombre nombre: " + lista.getFirst(),"ELIMINAR PRIMERO",JOptionPane.YES_NO_OPTION,JOptionPane.INFORMATION_MESSAGE, new ImageIcon("src/images/lapiz.gif"));
                                  
                                    if(eliminarPrimero == JOptionPane.YES_OPTION){
                                        
                                        lista.removeFirst();
                                    }
                                 
                                 break;
                                 
                             case 6 : 
                                 
                                  eliminarUltimo = JOptionPane.showConfirmDialog(null, "¿ Esta seguro(a) de eliminar el ultimo nombre de la lista ? \n" + "\nUltimo nombre: " + lista.getLast(),"ELIMINAR ULTIMO",JOptionPane.YES_NO_OPTION,JOptionPane.INFORMATION_MESSAGE, new ImageIcon("src/images/lapiz.gif"));
                                  
                                    if(eliminarUltimo == JOptionPane.YES_OPTION){
                                        
                                        lista.removeLast();
                                    }
                                 
                
                                 break;
                                 
                             case 7 : 
                                 
                                 
                                  for(int i = 0; i < lista.size(); i++){
                                             
                                              modificar += (i+1) + ". "+lista.get(i)+"\n";  }
                                         
                                          modificarNum =  Integer.parseInt(JOptionPane.showInputDialog("Por favor ingrese la posicion del nombre que desea Modificar\n" + "═══════════════════════════\n\n" + modificar+"\n")); 
                                          nuevoNombre = JOptionPane.showInputDialog(null, "Por favor ingrese un nuevo nombre\n" + "\nUsted esta moficando el nombre\n"+ "▬▬▬▬► '"+lista.get(modificarNum - 1)+"'" );
                                          lista.set(modificarNum - 1,nuevoNombre);
                                 break;
                                 
                             case 8 : 
                                 
                                        JOptionPane.showMessageDialog(null, "La cantidad de nombres en la lista son:  '" + lista.size() 
                                                                             + "'\n\n ↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓ \n\n" + lista, "TAMAÑO DE LINKEDLIST",JOptionPane.INFORMATION_MESSAGE, new ImageIcon("src/images/tamaño.jpg"));
                                 
                                 break;
                                 
                             case 9 : 
                                 
                                             limpiarLista = JOptionPane.showConfirmDialog(null, "¿Esta seguro(a) de eliminar la lista? " , "LIMPIAR LINKEDLIST", JOptionPane.YES_OPTION , JOptionPane.NO_OPTION, new ImageIcon("src/images/pensando.gif") );
                    
                                            if ( limpiarLista == JOptionPane.YES_OPTION){
                        
                                                       JOptionPane.showMessageDialog(null, "La lista ha sido borrada exitosamente","ELIMINAR LISTA",JOptionPane.INFORMATION_MESSAGE,new ImageIcon("src/images/correcto.jpg"));
                                                         lista.clear(); }
                                 
                                 
                                 break;
                                 
                               
                             case 10: 
                                 
                                 
                                  int seleccionar = JOptionPane.showConfirmDialog(null, "¿Realmente desea salir? " , "SALIDA" ,JOptionPane.YES_OPTION , JOptionPane.NO_OPTION,new ImageIcon("src/images/salir.gif") );
                                    if(seleccionar == JOptionPane.YES_OPTION ){
                                        System.exit(0);  }
                                    
                                   
                
                                  break;
                                 
                                default:
    
                         } //llave del switch
           
            


                    } catch (NumberFormatException e) {
                                JOptionPane.showMessageDialog(null, "Por favor ingrese un valor numerico","ATENCION",2);
                       
                     }
                
        
      
            
                } while(opcion != 10);            
                    
        
        
         
        
        
        
        
        
    }
    
}
